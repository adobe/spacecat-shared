/*
 * Copyright 2025 Adobe. All rights reserved.
 * This file is licensed to you under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License. You may obtain a copy
 * of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed under
 * the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR REPRESENTATIONS
 * OF ANY KIND, either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */

import crypto from 'crypto';
import { GetObjectCommand, PutObjectCommand } from '@aws-sdk/client-s3';
import {
  hasText, isNonEmptyObject, prependSchema, tracingFetch,
} from '@adobe/spacecat-shared-utils';
import { v4 as uuidv4 } from 'uuid';
import MapperRegistry from './mappers/mapper-registry.js';
import CdnClientRegistry from './cdn/cdn-client-registry.js';
import { mergePatches } from './utils/patch-utils.js';
import {
  getTokowakaConfigS3Path,
  getTokowakaMetaconfigS3Path,
  getHostName,
  normalizePath,
} from './utils/s3-utils.js';
import {
  omitKeys,
  isPatternSuggestion,
  groupSuggestionsByUrlPath,
  filterEligibleSuggestions,
  saveSuggestions,
  stripSuggestion,
  cleanupCoveredSuggestions,
  classifySuggestions,
  filterBatchCoveredSuggestions,
  findCoveredSuggestions,
} from './utils/suggestion-utils.js';
import { getEffectiveBaseURL } from './utils/site-utils.js';
import { removePatternFromMetaconfig, addPatternsToMetaconfig } from './utils/metaconfig-utils.js';
import { fetchHtmlWithWarmup, calculateForwardedHost } from './utils/custom-html-utils.js';
import { mapWithConcurrency } from './utils/concurrency-utils.js';
import {
  EDGE_OPTIMIZE_PROXY_BASE_URL_DEFAULT,
  PRIVATE_HOST_RE,
  WAF_PROBE_TIMEOUT_MS,
  classifyProbeResponse,
} from './utils/waf-probe-utils.js';

export { FastlyKVClient } from './fastly-kv-client.js';
export { calculateForwardedHost } from './utils/custom-html-utils.js';
export { SUGGESTION_BULK_UPDATE_TYPE } from './utils/suggestion-utils.js';

export { default as BaseValidator } from './validators/base-validator.js';
export { default as ValidatorRegistry } from './validators/validator-registry.js';
export {
  default as RoutingValidator,
  ROUTING_VALIDATOR_TYPE,
  ROUTING_VALIDATOR_USER_AGENT,
} from './validators/routing-validator.js';
export {
  OaeValidationJobs,
  OAE_VALIDATION_IMPORT_TYPE,
} from './oae-validation-job.js';

// CloudFront control-plane (free functions + constants).
export {
  assumeConnectorRole,
  listDistributions,
  getDistributionConfig,
  createOrigin,
  createCloudFrontFunction,
  updateCacheSettings,
  createLambdaAtEdge,
  getLambdaAtEdgeStatus,
  applyAssociations,
  verifyRouting,
  runDeployStep,
  planDeploy,
  CloudFrontEdgeClient,
  buildCloudfrontFunctionCode,
  buildLambdaZip,
} from './cdn/cloudfront/index.js';

const HTTP_BAD_REQUEST = 400;
const HTTP_INTERNAL_SERVER_ERROR = 500;
const HTTP_NOT_IMPLEMENTED = 501;

// URLs to deploy/roll back in parallel
const URL_CONFIG_CONCURRENCY = 5;

/**
 * Tokowaka Client - Manages edge optimization configurations
 */
class TokowakaClient {
  /**
   * Creates a TokowakaClient from context
   * @param {Object} context - The context object
   * @returns {TokowakaClient} - The client instance
   */
  static createFrom(context) {
    const { env, log = console, s3 } = context;
    const {
      TOKOWAKA_SITE_CONFIG_BUCKET: bucketName,
      TOKOWAKA_PREVIEW_BUCKET: previewBucketName,
      IMPORT_WORKER_QUEUE_URL: importWorkerQueueUrl,
    } = env;

    if (context.tokowakaClient) {
      return context.tokowakaClient;
    }

    const client = new TokowakaClient({
      bucketName,
      previewBucketName,
      s3Client: s3?.s3Client ?? context.s3Client,
      env,
      dataAccess: context.dataAccess,
      sqs: context.sqs,
      importWorkerQueueUrl,
    }, log);
    context.tokowakaClient = client;
    return client;
  }

  /**
   * Constructor
   * @param {Object} config - Configuration object
   * @param {string} config.bucketName - S3 bucket name for configs
   * @param {string} config.previewBucketName - S3 bucket name for preview configs
   * @param {Object} config.s3Client - AWS S3 client
   * @param {Object} config.env - Environment variables (for CDN credentials)
   * @param {Object} [config.dataAccess] - Data access layer
   *   (provides Suggestion.saveMany for batch saves)
   * @param {Object} [config.sqs] - SQS client (sendMessage(queueUrl, payload)). Used to offload
   *   very large covered-suggestion saves to the import worker instead of saving them directly.
   * @param {string} [config.importWorkerQueueUrl] - Import worker SQS queue URL.
   * @param {Object} log - Logger instance
   */
  constructor({
    bucketName, previewBucketName, s3Client, env = {}, dataAccess, sqs, importWorkerQueueUrl,
  }, log) {
    this.log = log;

    if (!hasText(bucketName)) {
      throw this.#createError('TOKOWAKA_SITE_CONFIG_BUCKET is required', HTTP_BAD_REQUEST);
    }

    if (!isNonEmptyObject(s3Client)) {
      throw this.#createError('S3 client is required', HTTP_BAD_REQUEST);
    }

    this.deployBucketName = bucketName;
    this.previewBucketName = previewBucketName;
    this.s3Client = s3Client;
    this.env = env;
    this.dataAccess = dataAccess;
    this.sqs = sqs;
    this.importWorkerQueueUrl = importWorkerQueueUrl;

    this.mapperRegistry = new MapperRegistry(log);
    this.cdnClientRegistry = new CdnClientRegistry(env, log);
  }

  #createError(message, status) {
    const error = Object.assign(new Error(message), { status });
    this.log.error(error.message);
    return error;
  }

  /**
   * Updates the metaconfig with deployed endpoint paths
   * @param {Object} metaconfig - Existing metaconfig object
   * @param {Array<string>} deployedUrls - Array of successfully deployed URLs
   * @param {string} baseUrl - Base URL for uploading metaconfig
   * @returns {Promise<void>}
   * @private
   */
  async #updateMetaconfigWithDeployedPaths(metaconfig, deployedUrls, baseUrl) {
    if (!Array.isArray(deployedUrls) || deployedUrls.length === 0) {
      return;
    }

    try {
      // Initialize patches field if it doesn't exist
      const updatedMetaconfig = {
        ...metaconfig,
        patches: { ...(metaconfig.patches || {}) },
      };

      // Extract normalized paths from deployed URLs and add to patches object
      deployedUrls.forEach((url) => {
        const urlObj = new URL(url);
        const normalizedPath = normalizePath(urlObj.pathname);
        updatedMetaconfig.patches[normalizedPath] = true;
      });

      await this.uploadMetaconfig(baseUrl, updatedMetaconfig);
      this.log.info(`Updated metaconfig with ${deployedUrls.length} deployed endpoint(s)`);
    } catch (error) {
      this.log.error(`Failed to update metaconfig with deployed paths: ${error.message}`, error);
      throw this.#createError(
        `Failed to update metaconfig with deployed paths: ${error.message}`,
        HTTP_INTERNAL_SERVER_ERROR,
      );
    }
  }

  /**
   * Gets the list of CDN providers from environment configuration
   * Supports both single provider (string) and multiple providers (comma-separated string or array)
   * @returns {Array<string>} Array of CDN provider names
   * @private
   */
  #getCdnProviders() {
    const providerConfig = this.env.TOKOWAKA_CDN_PROVIDER;

    if (!providerConfig) {
      return [];
    }

    // If it's already an array, return it
    if (Array.isArray(providerConfig)) {
      return providerConfig.filter(Boolean);
    }

    // If it's a comma-separated string, split it
    if (typeof providerConfig === 'string') {
      return providerConfig
        .split(',')
        .map((p) => p.trim())
        .filter(Boolean);
    }

    return [];
  }

  /**
   * Generates Tokowaka site configuration from suggestions for a specific URL
   * @param {string} url - Full URL for which to generate config
   * @param {Object} opportunity - Opportunity entity
   * @param {Array} suggestionsToDeploy - Array of suggestion entities to deploy
   * @returns {Object} - Tokowaka configuration object for the URL
   */
  generateConfig(url, opportunity, suggestionsToDeploy) {
    const opportunityType = opportunity.getType();

    const mapper = this.mapperRegistry.getMapper(opportunityType);
    if (!mapper) {
      throw this.#createError(
        `No mapper found for opportunity type: ${opportunityType}. `
        + `Supported types: ${this.mapperRegistry.getSupportedOpportunityTypes().join(', ')}`,
        HTTP_NOT_IMPLEMENTED,
      );
    }

    // Extract URL path from the full URL
    const urlObj = new URL(url);
    const urlPath = urlObj.pathname;

    // Generate patches for the URL using the mapper
    const patches = mapper.suggestionsToPatches(
      urlPath,
      suggestionsToDeploy,
      opportunity.getId(),
    );

    // Check if configs without patches are allowed (e.g., prerender-only)
    if (patches.length === 0 && !mapper.allowConfigsWithoutPatch()) {
      return null;
    }

    return {
      url,
      version: '1.0',
      forceFail: false,
      prerender: mapper.requiresPrerender(),
      patches,
    };
  }

  /**
   * Gets list of supported opportunity types
   * @returns {string[]} - Array of supported opportunity types
   */
  getSupportedOpportunityTypes() {
    return this.mapperRegistry.getSupportedOpportunityTypes();
  }

  /**
   * Registers a custom mapper for an opportunity type
   * @param {BaseOpportunityMapper} mapper - Mapper instance
   */
  registerMapper(mapper) {
    this.mapperRegistry.registerMapper(mapper);
  }

  /**
   * Internal method to fetch domain-level metaconfig from S3 with metadata
   * @param {string} url - Full URL (used to extract domain)
   * @returns {Promise<Object|null>} - Object with metaconfig and s3Metadata,
   *   or null if not found
   * @private
   */
  async #fetchMetaconfigWithMetadata(url) {
    if (!hasText(url)) {
      throw this.#createError('URL is required', HTTP_BAD_REQUEST);
    }

    const fetchStartTime = Date.now();
    const s3Path = getTokowakaMetaconfigS3Path(url, this.log);
    const bucketName = this.deployBucketName;

    try {
      const command = new GetObjectCommand({
        Bucket: bucketName,
        Key: s3Path,
      });

      const response = await this.s3Client.send(command);
      const bodyContents = await response.Body.transformToString();
      const metaconfig = JSON.parse(bodyContents);

      // eslint-disable-next-line max-len
      this.log.debug(`Successfully fetched metaconfig from s3://${bucketName}/${s3Path} in ${Date.now() - fetchStartTime}ms`);

      return {
        metaconfig,
        s3Metadata: response.Metadata || {},
      };
    } catch (error) {
      // If metaconfig doesn't exist (NoSuchKey), return null
      if (error.name === 'NoSuchKey' || error.Code === 'NoSuchKey') {
        this.log.debug(`No metaconfig found at s3://${bucketName}/${s3Path}`);
        return null;
      }

      // For other errors, log and throw
      this.log.error(`Failed to fetch metaconfig from S3: ${error.message}`, error);
      throw this.#createError(`S3 fetch failed: ${error.message}`, HTTP_INTERNAL_SERVER_ERROR);
    }
  }

  /**
   * Fetches domain-level metaconfig from S3
   * @param {string} url - Full URL (used to extract domain)
   * @returns {Promise<Object|null>} - Metaconfig object or null if not found
   */
  async fetchMetaconfig(url) {
    const result = await this.#fetchMetaconfigWithMetadata(url);
    return result?.metaconfig ?? null;
  }

  /**
   * Generates an API key for Tokowaka based on domain
   * @param {string} domain - Domain name (e.g., 'example.com')
   * @returns {string} - Base64 URL-encoded API key
   * @private
   */
  /* eslint-disable class-methods-use-this */
  #generateApiKey(normalizedHostName) {
    const uuid = uuidv4();
    return crypto
      .createHash('sha256')
      .update(`${uuid}${normalizedHostName}`)
      .digest('base64url');
  }

  /**
   * Creates and uploads domain-level metaconfig to S3 if it does not exists
   * Generates a new API key and creates the metaconfig structure
   * @param {string} url - Full URL (used to extract domain)
   * @param {string} siteId - Site ID
   * @param {Object} options - Optional configuration
   * @param {boolean} options.enhancements - Whether to enable enhancements
   *   (default: true)
   * @param {Object} metadata - Optional S3 user-defined metadata for
   *   audit trail and behavior flags
   * @param {string} metadata.lastModifiedBy - User who modified the config
   * @param {boolean} metadata.isStageDomain - Whether this is a staging
   *   domain (enables wildcard prerender)
   * @returns {Promise<Object>} - Object with s3Path and metaconfig
   */
  async createMetaconfig(url, siteId, options = {}, metadata = {}) {
    if (!hasText(url)) {
      throw this.#createError('URL is required', HTTP_BAD_REQUEST);
    }

    const existingMetaconfig = await this.fetchMetaconfig(url);

    if (existingMetaconfig) {
      throw this.#createError('Metaconfig already exists for this URL', HTTP_BAD_REQUEST);
    }

    if (!hasText(siteId)) {
      throw this.#createError('Site ID is required', HTTP_BAD_REQUEST);
    }

    const normalizedHostName = getHostName(url, this.log);
    const apiKey = this.#generateApiKey(normalizedHostName);

    const metaconfig = {
      siteId,
      apiKeys: [apiKey],
      tokowakaEnabled: true,
      enhancements: options.enhancements ?? true,
      patches: {},
    };

    // Handle staging domain with automatic prerender configuration
    const isStageDomain = metadata.isStageDomain === true;
    if (isStageDomain) {
      metaconfig.prerender = { allowList: ['/*'] };
    }

    // Persist isStageDomain in S3 metadata for future updates
    const s3Metadata = {
      ...metadata,
      ...(isStageDomain && { isStageDomain: 'true' }),
    };

    const s3Path = await this.uploadMetaconfig(url, metaconfig, s3Metadata);
    this.log.info(`Created new Tokowaka metaconfig for ${normalizedHostName} at ${s3Path}`);

    return metaconfig;
  }

  /**
   * Updates domain-level metaconfig to S3 if it does not exists
   * Reuses the same API key and updates the metaconfig structure
   * @param {string} url - Full URL (used to extract domain)
   * @param {string} siteId - Site ID
   * @param {Object} options - Optional configuration
   * @param {Object} metadata - Optional S3 user-defined metadata for
   *   audit trail and behavior flags
   * @param {string} metadata.lastModifiedBy - User who modified the config
   * @param {boolean} metadata.isStageDomain - Whether this is a staging
   *   domain (enables wildcard prerender)
   * @returns {Promise<Object>} - Object with s3Path and metaconfig
   */
  async updateMetaconfig(url, siteId, options = {}, metadata = {}) {
    if (!hasText(url)) {
      throw this.#createError('URL is required', HTTP_BAD_REQUEST);
    }

    const raw = await this.#fetchMetaconfigWithMetadata(url);
    if (!raw?.metaconfig) {
      throw this.#createError('Metaconfig does not exist for this URL', HTTP_BAD_REQUEST);
    }
    const { metaconfig: existingMetaconfig, s3Metadata: existingS3Metadata } = raw;

    if (!hasText(siteId)) {
      throw this.#createError('Site ID is required', HTTP_BAD_REQUEST);
    }

    const normalizedHostName = getHostName(url, this.log);

    // dont override api keys
    // if patches exist, they cannot reset to empty object
    const hasForceFail = options.forceFail !== undefined
      || existingMetaconfig.forceFail !== undefined;
    const forceFail = options.forceFail
      ?? existingMetaconfig.forceFail
      ?? false;

    // Handle staging domain: check from metadata or from existing S3 metadata (S3 lowercases keys)
    const isStageDomain = metadata.isStageDomain === true
      || existingS3Metadata.isstagedomain === 'true';

    const hasPrerender = isStageDomain
      || isNonEmptyObject(options.prerender)
      || isNonEmptyObject(existingMetaconfig.prerender);

    const prerender = isStageDomain
      ? { allowList: ['/*'] }
      : (options.prerender ?? existingMetaconfig.prerender);

    const metaconfig = {
      ...existingMetaconfig,
      tokowakaEnabled: options.tokowakaEnabled ?? existingMetaconfig.tokowakaEnabled ?? true,
      enhancements: options.enhancements ?? existingMetaconfig.enhancements ?? true,
      patches: isNonEmptyObject(options.patches)
        ? options.patches
        : (existingMetaconfig.patches ?? {}),
      ...(hasForceFail && { forceFail }),
      ...(hasPrerender && { prerender }),
    };

    // Persist isStageDomain in S3 metadata for future updates
    const s3Metadata = {
      ...metadata,
      ...(isStageDomain && { isStageDomain: 'true' }),
    };

    const uploadedPath = await this.uploadMetaconfig(url, metaconfig, s3Metadata);
    this.log.info(`Updated Tokowaka metaconfig for ${normalizedHostName} at ${uploadedPath}`);

    return metaconfig;
  }

  /**
   * Uploads domain-level metaconfig to S3
   * @param {string} url - Full URL (used to extract domain)
   * @param {Object} metaconfig - Metaconfig object (siteId, apiKeys, prerender)
   * @param {Object} metadata - Optional S3 user-defined metadata (key-value pairs)
   * @returns {Promise<string>} - S3 key of uploaded metaconfig
  */
  async uploadMetaconfig(url, metaconfig, metadata = {}) {
    if (!hasText(url)) {
      throw this.#createError('URL is required', HTTP_BAD_REQUEST);
    }

    if (!isNonEmptyObject(metaconfig)) {
      throw this.#createError('Metaconfig object is required', HTTP_BAD_REQUEST);
    }

    const uploadStartTime = Date.now();
    const s3Path = getTokowakaMetaconfigS3Path(url, this.log);
    const bucketName = this.deployBucketName;

    try {
      const putObjectParams = {
        Bucket: bucketName,
        Key: s3Path,
        Body: JSON.stringify(metaconfig, null, 2),
        ContentType: 'application/json',
      };

      // Add user-defined metadata if provided
      if (isNonEmptyObject(metadata)) {
        putObjectParams.Metadata = metadata;
      }

      const command = new PutObjectCommand(putObjectParams);

      await this.s3Client.send(command);
      // eslint-disable-next-line max-len
      this.log.info(`Successfully uploaded metaconfig to s3://${bucketName}/${s3Path} in ${Date.now() - uploadStartTime}ms`);

      // Invalidate CDN cache for the metaconfig (both CloudFront and Fastly)
      this.log.info('Invalidating CDN cache for uploaded metaconfig');
      await this.invalidateCdnCache({ paths: [`/${s3Path}`] });

      return s3Path;
    } catch (error) {
      this.log.error(`Failed to upload metaconfig to S3: ${error.message}`, error);
      throw this.#createError(`S3 upload failed: ${error.message}`, HTTP_INTERNAL_SERVER_ERROR);
    }
  }

  /**
   * Fetches existing Tokowaka configuration from S3 for a specific URL
   * @param {string} url - Full URL (e.g., 'https://www.example.com/products/item')
   * @param {boolean} isPreview - Whether to fetch from preview path (default: false)
   * @returns {Promise<Object|null>} - Existing configuration object or null if not found
   */
  async fetchConfig(url, isPreview = false) {
    if (!hasText(url)) {
      throw this.#createError('URL is required', HTTP_BAD_REQUEST);
    }

    const fetchStartTime = Date.now();
    const s3Path = getTokowakaConfigS3Path(url, this.log, isPreview);
    const bucketName = isPreview ? this.previewBucketName : this.deployBucketName;

    try {
      const command = new GetObjectCommand({
        Bucket: bucketName,
        Key: s3Path,
      });

      const response = await this.s3Client.send(command);
      const bodyContents = await response.Body.transformToString();
      const config = JSON.parse(bodyContents);

      // eslint-disable-next-line max-len
      this.log.debug(`Successfully fetched existing Tokowaka config from s3://${bucketName}/${s3Path} in ${Date.now() - fetchStartTime}ms`);
      return config;
    } catch (error) {
      // If config doesn't exist (NoSuchKey), return null
      if (error.name === 'NoSuchKey' || error.Code === 'NoSuchKey') {
        this.log.debug(`No existing Tokowaka config found at s3://${bucketName}/${s3Path}`);
        return null;
      }

      // For other errors, log and throw
      this.log.error(`Failed to fetch Tokowaka config from S3: ${error.message}`, error);
      throw this.#createError(`S3 fetch failed: ${error.message}`, HTTP_INTERNAL_SERVER_ERROR);
    }
  }

  /**
   * Merges existing configuration with new configuration
   * Checks patch key:
   * - Patches are identified by opportunityId+suggestionId
   * - Heading patches (no suggestionId) are identified by opportunityId
   * - If exists: updates the patch
   * - If not exists: adds new patch to the array
   * @param {Object} existingConfig - Existing configuration from S3
   * @param {Object} newConfig - New configuration generated from suggestions
   * @returns {Object} - Merged configuration
   */
  mergeConfigs(existingConfig, newConfig) {
    if (!existingConfig) {
      return newConfig;
    }

    const existingPatches = existingConfig.patches || [];
    const newPatches = newConfig.patches || [];

    const { patches: mergedPatches, updateCount, addCount } = mergePatches(
      existingPatches,
      newPatches,
    );

    this.log.debug(`Merged patches: ${updateCount} updated, ${addCount} added`);

    return {
      ...existingConfig,
      url: newConfig.url,
      version: newConfig.version,
      forceFail: newConfig.forceFail,
      prerender: newConfig.prerender,
      patches: mergedPatches,
    };
  }

  /**
   * Uploads Tokowaka configuration to S3 for a specific URL
   * @param {string} url - Full URL (e.g., 'https://www.example.com/products/item')
   * @param {Object} config - Tokowaka configuration object
   * @param {boolean} isPreview - Whether to upload to preview path (default: false)
   * @returns {Promise<string>} - S3 key of uploaded config
   */
  async uploadConfig(url, config, isPreview = false) {
    if (!hasText(url)) {
      throw this.#createError('URL is required', HTTP_BAD_REQUEST);
    }

    if (!isNonEmptyObject(config)) {
      throw this.#createError('Config object is required', HTTP_BAD_REQUEST);
    }
    const uploadStartTime = Date.now();

    const s3Path = getTokowakaConfigS3Path(url, this.log, isPreview);
    const bucketName = isPreview ? this.previewBucketName : this.deployBucketName;

    try {
      const command = new PutObjectCommand({
        Bucket: bucketName,
        Key: s3Path,
        Body: JSON.stringify(config, null, 2),
        ContentType: 'application/json',
      });

      await this.s3Client.send(command);
      // eslint-disable-next-line max-len
      this.log.info(`Successfully uploaded Tokowaka config to s3://${bucketName}/${s3Path} in ${Date.now() - uploadStartTime}ms`);

      return s3Path;
    } catch (error) {
      this.log.error(`Failed to upload Tokowaka config to S3: ${error.message}`, error);
      throw this.#createError(`S3 upload failed: ${error.message}`, HTTP_INTERNAL_SERVER_ERROR);
    }
  }

  /**
   * CDN cache invalidation method that supports invalidating URL configs
   * or custom S3 paths across provided or default CDN providers.
   * @param {Object} options - Invalidation options
   * @param {Array<string>} options.urls - Array of full URLs to invalidate (for URL configs)
   * @param {Array<string>} options.paths - Custom S3 paths to invalidate directly
   * @param {string|Array<string>} options.providers - CDN provider name(s)
   *  (default: all supported providers)
   * @param {boolean} options.isPreview - Whether to invalidate preview paths (default: false)
   * @returns {Promise<Array<Object>>} - Array of CDN invalidation results
   */
  async invalidateCdnCache({
    urls = [],
    paths = [],
    providers = this.#getCdnProviders(),
    isPreview = false,
  }) {
    const invalidationStartTime = Date.now();
    // Convert single provider to array for uniform handling
    const providerList = Array.isArray(providers) ? providers : [providers].filter(Boolean);

    if (providerList.length === 0) {
      this.log.warn('No CDN providers specified for cache invalidation');
      return [];
    }

    // Build list of paths to invalidate
    const pathsToInvalidate = [...paths];

    // Add URL config paths
    if (urls.length > 0) {
      const urlPaths = urls.map((url) => `/${getTokowakaConfigS3Path(url, this.log, isPreview)}`);
      pathsToInvalidate.push(...urlPaths);
    }

    // Return early if no paths to invalidate
    if (pathsToInvalidate.length === 0) {
      this.log.debug('No paths to invalidate for CDN cache');
      return [];
    }

    this.log.info(
      `Invalidating CDN cache for ${pathsToInvalidate.length} path(s) `
      + `via providers: ${providerList.join(', ')}`,
    );

    const results = [];
    for (const provider of providerList) {
      try {
        const cdnClient = this.cdnClientRegistry.getClient(provider);
        if (!cdnClient) {
          this.log.warn(`No CDN client available for provider: ${provider}`);
          results.push({
            status: 'error',
            provider,
            message: `No CDN client available for provider: ${provider}`,
          });
          // eslint-disable-next-line no-continue
          continue;
        }

        const startTime = Date.now();
        // eslint-disable-next-line no-await-in-loop
        const result = await cdnClient.invalidateCache(pathsToInvalidate);
        this.log.info(
          `CDN cache invalidation completed for ${provider}: `
          + `${pathsToInvalidate.length} path(s), and took ${Date.now() - startTime}ms`,
        );
        results.push(result);
      } catch (error) {
        this.log.warn(`Failed to invalidate ${provider} CDN cache: ${error.message}`, error);
        results.push({
          status: 'error',
          provider,
          message: error.message,
        });
      }
    }
    // eslint-disable-next-line max-len
    this.log.info(`CDN cache invalidation completed in total ${Date.now() - invalidationStartTime}ms`);
    return results;
  }

  /**
   * Deploys suggestions to Tokowaka by generating patch config and uploading to S3
   * @param {Object} site - Site entity
   * @param {Object} opportunity - Opportunity entity
   * @param {Array} suggestions - Array of suggestion entities to deploy
   * @returns {Promise<Object>} - Deployment result with succeeded/failed suggestions
   */
  async deploySuggestions(site, opportunity, suggestions, metadata = {}) {
    const { applyStale = false } = metadata;
    const opportunityType = opportunity.getType();
    const baseURL = getEffectiveBaseURL(site);
    const mapper = this.mapperRegistry.getMapper(opportunityType);
    if (!mapper) {
      throw this.#createError(
        `No mapper found for opportunity type: ${opportunityType}. `
        + `Supported types: ${this.mapperRegistry.getSupportedOpportunityTypes().join(', ')}`,
        HTTP_NOT_IMPLEMENTED,
      );
    }

    // Validate which suggestions can be deployed using mapper's canDeploy method
    const {
      eligible: eligibleSuggestions,
      ineligible: ineligibleSuggestions,
    } = filterEligibleSuggestions(suggestions, mapper);

    this.log.debug(
      `Deploying ${eligibleSuggestions.length} eligible suggestions `
      + `(${ineligibleSuggestions.length} ineligible)`,
    );

    if (eligibleSuggestions.length === 0) {
      this.log.warn('No eligible suggestions to deploy');
      return {
        succeededSuggestions: [],
        failedSuggestions: ineligibleSuggestions,
      };
    }

    // Group suggestions by URL
    const suggestionsByUrl = groupSuggestionsByUrlPath(eligibleSuggestions, baseURL, this.log);

    // Check if domain-level metaconfig exists
    const firstUrl = new URL(Object.keys(suggestionsByUrl)[0], baseURL).toString();
    const metaconfig = await this.fetchMetaconfig(firstUrl);

    if (!metaconfig) {
      throw this.#createError(
        'No domain-level metaconfig found. '
        + 'A domain-level metaconfig needs to be created first before deploying suggestions.',
        HTTP_BAD_REQUEST,
      );
    }

    // Each URL has its own S3 config, so we can handle several at the same time.
    const urlEntries = Object.entries(suggestionsByUrl);
    const loopStart = Date.now();
    const processed = await mapWithConcurrency(
      urlEntries,
      async ([urlPath, urlSuggestions]) => {
        const fullUrl = new URL(urlPath, baseURL).toString();
        this.log.debug(`Processing ${urlSuggestions.length} suggestions for URL: ${fullUrl}`);

        // Fetch existing configuration for this URL from S3
        const existingConfig = await this.fetchConfig(fullUrl);

        // Generate configuration for this URL with eligible suggestions only
        const newConfig = this.generateConfig(fullUrl, opportunity, urlSuggestions);

        if (!newConfig) {
          this.log.warn(`No config generated for URL: ${fullUrl}`);
          return null;
        }

        // Check if mapper allows configs without patches (e.g., prerender-only config)
        const allowsNoPatch = mapper.allowConfigsWithoutPatch() && newConfig.patches.length === 0;

        if (!allowsNoPatch && (!newConfig.patches || newConfig.patches.length === 0)) {
          this.log.warn(`No eligible suggestions to deploy for URL: ${fullUrl}`);
          return null;
        }

        if (applyStale && newConfig.patches?.length > 0) {
          newConfig.patches = newConfig.patches.map((patch) => ({ ...patch, applyStale: true }));
        }

        // Merge with existing config for this URL
        const config = this.mergeConfigs(existingConfig, newConfig);

        // Upload to S3
        const s3Path = await this.uploadConfig(fullUrl, config);
        return { s3Path, fullUrl };
      },
      URL_CONFIG_CONCURRENCY,
    );

    const s3Paths = [];
    const deployedUrls = []; // Track URLs for batch CDN invalidation
    processed.forEach((entry) => {
      if (entry) {
        s3Paths.push(entry.s3Path);
        deployedUrls.push(entry.fullUrl);
      }
    });

    this.log.info(`Uploaded Tokowaka configs for ${s3Paths.length}/${urlEntries.length}`
      + ` URL(s) in ${Date.now() - loopStart}ms (concurrency=${URL_CONFIG_CONCURRENCY})`);

    // Update metaconfig with deployed paths
    await this.#updateMetaconfigWithDeployedPaths(metaconfig, deployedUrls, baseURL);

    // Invalidate CDN cache for all deployed URLs at once
    const cdnInvalidations = await this.invalidateCdnCache({ urls: deployedUrls });

    return {
      s3Paths,
      cdnInvalidations,
      succeededSuggestions: eligibleSuggestions,
      failedSuggestions: ineligibleSuggestions,
    };
  }

  /**
   * Rolls back a single URL's S3 config by removing the relevant patches.
   * Returns { s3Path, fullUrl, removed } when a config was re-uploaded,
   * or null when there was nothing to roll back
   * @param {string} fullUrl
   * @param {Array} urlSuggestions - Suggestions for this URL
   * @param {Object} opportunity
   * @param {Object} mapper
   * @param {string} opportunityType
   * @returns {Promise<{s3Path: string, fullUrl: string, removed: number}|null>}
   * @private
   */
  async #rollbackPerUrlConfig(
    fullUrl,
    urlSuggestions,
    opportunity,
    mapper,
    opportunityType,
  ) {
    const existingConfig = await this.fetchConfig(fullUrl);
    if (!existingConfig) {
      this.log.warn(`No existing configuration found for URL: ${fullUrl}`);
      return null;
    }

    if (opportunityType === 'prerender') {
      this.log.info(`Rolling back prerender config for URL: ${fullUrl}`);
      const s3Path = await this.uploadConfig(fullUrl, { ...existingConfig, prerender: false });
      return { s3Path, fullUrl, removed: 1 };
    }

    if (!existingConfig.patches) {
      this.log.info(`No patches found in configuration for URL: ${fullUrl}`);
      return null;
    }

    const suggestionIdsToRemove = urlSuggestions.map((s) => s.getId());
    const updatedConfig = mapper.rollbackPatches(
      existingConfig,
      suggestionIdsToRemove,
      opportunity.getId(),
    );

    if (updatedConfig.removedCount === 0) {
      this.log.warn(`No patches found for suggestions at URL: ${fullUrl}`);
      return null;
    }

    this.log.info(`Removed ${updatedConfig.removedCount} patches for URL: ${fullUrl}`);
    const removed = updatedConfig.removedCount;
    delete updatedConfig.removedCount;

    const s3Path = await this.uploadConfig(fullUrl, updatedConfig);
    return { s3Path, fullUrl, removed };
  }

  /**
   * Rolls back deployed suggestions by removing their patches from the configuration
   * Now updates one file per URL instead of a single file with all URLs
   * @param {Object} site - Site entity
   * @param {Object} opportunity - Opportunity entity
   * @param {Array} suggestions - Array of suggestion entities to rollback
   * @param {Object} [options] - Optional parameters
   * @param {Array} [options.allSuggestions=[]] - All suggestions for the opportunity,
   *   used to clean up suggestions covered by a domain-wide or path-level pattern rollback
   * @param {string} [options.updatedBy] - Actor identity (e.g. profile email). When undefined,
   *   context-specific fallback strings are used: 'tokowaka-rollback' for direct suggestions,
   *   'domain-wide-rollback' for per-URL suggestions covered by a domain-wide pattern, and
   *   'path-rollback' for per-URL suggestions covered by a path pattern.
   * @returns {Promise<Object>} - Rollback result with succeeded/failed suggestions
   */
  // eslint-disable-next-line max-len
  async rollbackSuggestions(site, opportunity, suggestions, { allSuggestions = [], updatedBy } = {}) {
    const opportunityType = opportunity.getType();
    const baseURL = getEffectiveBaseURL(site);
    const mapper = this.mapperRegistry.getMapper(opportunityType);
    if (!mapper) {
      throw this.#createError(
        `No mapper found for opportunity type: ${opportunityType}. `
        + `Supported types: ${this.mapperRegistry.getSupportedOpportunityTypes().join(', ')}`,
        HTTP_NOT_IMPLEMENTED,
      );
    }

    // Separate pattern-based suggestions (path and domain-wide allowList entries)
    // from per-URL suggestions — each group is rolled back via a different code path.
    const patternSuggestions = suggestions.filter(isPatternSuggestion);
    const perUrlSuggestions = suggestions.filter((s) => !isPatternSuggestion(s));
    // eslint-disable-next-line max-len
    this.log.info(`[edge-rollback] Site: ${baseURL}, total: ${suggestions.length}, pattern: ${patternSuggestions.length}, perUrl: ${perUrlSuggestions.length}, allSuggestions: ${allSuggestions.length}`);

    const {
      eligible: eligibleSuggestions,
      ineligible: ineligibleSuggestions,
    } = filterEligibleSuggestions(perUrlSuggestions, mapper);

    this.log.debug(
      `Rolling back ${eligibleSuggestions.length} eligible suggestions `
      + `(${ineligibleSuggestions.length} ineligible), `
      + `${patternSuggestions.length} pattern suggestions`,
    );

    if (eligibleSuggestions.length === 0 && patternSuggestions.length === 0) {
      this.log.warn('No eligible suggestions to rollback');
      return {
        succeededSuggestions: [],
        failedSuggestions: ineligibleSuggestions,
      };
    }

    // Roll back per-URL suggestions: one S3 config file per URL.
    const suggestionsByUrl = groupSuggestionsByUrlPath(eligibleSuggestions, baseURL, this.log);

    // Each URL is its own file, so we can roll back several at the same time.
    const urlEntries = Object.entries(suggestionsByUrl);
    const loopStart = Date.now();
    const processed = await mapWithConcurrency(
      urlEntries,
      async ([urlPath, urlSuggestions]) => {
        const fullUrl = new URL(urlPath, baseURL).toString();
        this.log.debug(`Rolling back ${urlSuggestions.length} suggestions for URL: ${fullUrl}`);
        return this.#rollbackPerUrlConfig(
          fullUrl,
          urlSuggestions,
          opportunity,
          mapper,
          opportunityType,
        );
      },
      URL_CONFIG_CONCURRENCY,
    );

    const s3Paths = [];
    const rolledBackUrls = [];
    let totalRemovedCount = 0;
    processed.forEach((entry) => {
      if (entry) {
        s3Paths.push(entry.s3Path);
        rolledBackUrls.push(entry.fullUrl);
        totalRemovedCount += entry.removed;
      }
    });

    // eslint-disable-next-line max-len
    this.log.info(`Updated Tokowaka configs for ${s3Paths.length}/${urlEntries.length} URL(s), `
      + `removed ${totalRemovedCount} patches total in ${Date.now() - loopStart}ms (concurrency=${URL_CONFIG_CONCURRENCY})`);

    // Strip deployment markers and batch-save all eligible per-URL suggestions.
    const savedEligibleSuggestions = eligibleSuggestions
      .map((s) => stripSuggestion(s, 'tokowaka-rollback', updatedBy));
    await saveSuggestions(this.dataAccess, savedEligibleSuggestions);

    // Roll back pattern suggestions: fetch metaconfig once, remove all patterns in a single
    // in-memory pass, upload once, then save each suggestion and clean up its covered entries.
    const succeededPatternSuggestions = [];
    const failedPatternSuggestions = [];

    if (patternSuggestions.length > 0) {
      const metaconfig = await this.fetchMetaconfig(baseURL);
      if (!metaconfig) {
        // eslint-disable-next-line max-len
        this.log.warn(`[edge-rollback] No metaconfig found for ${baseURL}, skipping all pattern suggestions`);
        // eslint-disable-next-line max-len
        patternSuggestions.forEach((s) => ineligibleSuggestions.push({ suggestion: s, reason: 'No metaconfig found' }));
      } else {
        // Pass 1: remove all patterns from the in-memory metaconfig, stage suggestions for saving.
        const toSave = [];
        let metaconfigChanged = false;

        for (const suggestion of patternSuggestions) {
          const data = suggestion.getData();
          const patternToRemove = data?.allowedRegexPatterns?.[0];
          if (!patternToRemove) {
            // eslint-disable-next-line max-len
            this.log.warn(`[edge-rollback] Suggestion ${suggestion.getId()} has no allowedRegexPatterns, skipping`);
            ineligibleSuggestions.push({ suggestion, reason: 'Missing allowedRegexPatterns' });
            // eslint-disable-next-line no-continue
            continue;
          }

          const existingAllowList = metaconfig.prerender?.allowList ?? [];
          const changed = removePatternFromMetaconfig(metaconfig, patternToRemove);
          const updatedAllowList = metaconfig.prerender?.allowList ?? [];
          // eslint-disable-next-line max-len
          this.log.info(`[edge-rollback] Pattern ${patternToRemove}: allowList before=${JSON.stringify(existingAllowList)}, after=${JSON.stringify(updatedAllowList)}`);
          if (changed) {
            metaconfigChanged = true;
          } else {
            // eslint-disable-next-line max-len
            this.log.info(`[edge-rollback] Pattern ${patternToRemove} not found in allowList, skipping CDN write`);
          }

          suggestion.setData(omitKeys(data, ['edgeDeployed', 'tokowakaDeployed']));
          suggestion.setUpdatedBy(updatedBy ?? 'tokowaka-rollback');
          toSave.push(suggestion);
        }

        // Pass 2: upload the mutated metaconfig once, then save each suggestion and clean up.
        try {
          if (metaconfigChanged) {
            await this.uploadMetaconfig(baseURL, metaconfig);
            this.log.info(`[edge-rollback] Metaconfig upload succeeded for ${baseURL}`);
          }
        } catch (error) {
          this.log.error(`[edge-rollback] Metaconfig upload failed: ${error.message}`, error);
          toSave.forEach((s) => failedPatternSuggestions.push({
            suggestion: s, reason: 'Internal server error', statusCode: 500,
          }));
          // Skip per-suggestion saves when metaconfig upload failed
          toSave.length = 0;
        }

        // Batch-save all pattern suggestions.
        if (toSave.length > 0) {
          try {
            await saveSuggestions(this.dataAccess, toSave);
            succeededPatternSuggestions.push(...toSave);
            // Logs the exact payload that was just persisted, per suggestion, so a discrepancy
            // between "save reported success" and "the DB still shows the old value" is visible
            // from this log alone rather than requiring a follow-up GET.
            toSave.forEach((s) => {
              // eslint-disable-next-line max-len
              this.log.info(`[edge-rollback] Saved pattern suggestion ${s.getId()}: edgeDeployed=${s.getData()?.edgeDeployed ?? 'undefined'}, tokowakaDeployed=${s.getData()?.tokowakaDeployed ?? 'undefined'}`);
            });
          } catch (error) {
            // eslint-disable-next-line max-len
            this.log.error(`[edge-rollback] Error saving pattern suggestions: ${error.message}`);
            toSave.forEach((s) => failedPatternSuggestions.push({
              suggestion: s, reason: 'Internal server error', statusCode: 500,
            }));
          }
        }

        // Clean up covered suggestions for each succeeded pattern suggestion.
        for (const suggestion of succeededPatternSuggestions) {
          const suggData = suggestion.getData();
          const isDomainWide = suggData?.isDomainWide === true;
          const coveredFallback = isDomainWide ? 'domain-wide-rollback' : 'path-rollback';
          const coverageField = isDomainWide
            ? 'coveredByDomainWide' : 'coveredByPattern';
          const covered = allSuggestions.filter(
            (s) => s.getData()?.[coverageField] === suggestion.getId(),
          );
          const fieldsToStrip = isDomainWide
            ? ['coveredByDomainWide']
            : ['edgeDeployed', 'tokowakaDeployed', 'coveredByPattern'];
          if (covered.length > 0) {
            // eslint-disable-next-line max-len
            this.log.info(`[edge-rollback] Cleaning ${covered.length} covered suggestion(s) for pattern ${suggestion.getId()} (isDomainWide=${isDomainWide}, fallback=${coveredFallback})`);
          }
          // eslint-disable-next-line no-await-in-loop, max-len
          await cleanupCoveredSuggestions(this.dataAccess, covered, coveredFallback, updatedBy, fieldsToStrip, this.log, {
            sqs: this.sqs,
            queueUrl: this.importWorkerQueueUrl,
            siteId: site.getId(),
            unset: fieldsToStrip,
            updatedBy: updatedBy ?? coveredFallback,
            log: this.log,
          });
        }
      }
    }

    const cdnInvalidations = await this.invalidateCdnCache({ urls: rolledBackUrls });

    const allSucceeded = [...savedEligibleSuggestions, ...succeededPatternSuggestions];
    const allFailed = [...ineligibleSuggestions, ...failedPatternSuggestions];
    const total = allSucceeded.length + allFailed.length;

    if (allFailed.length > 0) {
      // eslint-disable-next-line max-len
      this.log.error(`[edge-rollback-failed] ${allFailed.length} out of ${total} suggestion(s) failed to rollback for ${baseURL}`);
    }

    return {
      s3Paths,
      cdnInvalidations,
      succeededSuggestions: allSucceeded,
      failedSuggestions: allFailed,
      removedPatchesCount: totalRemovedCount,
    };
  }

  /**
   * Previews suggestions by generating config and uploading to preview path
   * All suggestions must belong to the same URL
   * @param {Object} site - Site entity
   * @param {Object} opportunity - Opportunity entity
   * @param {Array} suggestions - Array of suggestion entities to preview (must be same URL)
   * @param {Object} options - Optional configuration for HTML fetching
   * @returns {Promise<Object>} - Preview result with config and succeeded/failed suggestions
   */
  async previewSuggestions(site, opportunity, suggestions = [], options = {}) {
    const opportunityType = opportunity.getType();
    this.log.info(`Previewing ${suggestions.length} suggestions for `
       + `${opportunityType} opportunity and URL ${site.getBaseURL()}`);
    const mapper = this.mapperRegistry.getMapper(opportunityType);
    if (!mapper) {
      throw this.#createError(
        `No mapper found for opportunity type: ${opportunityType}. `
        + `Supported types: ${this.mapperRegistry.getSupportedOpportunityTypes().join(', ')}`,
        HTTP_NOT_IMPLEMENTED,
      );
    }

    // TOKOWAKA_EDGE_URL is mandatory for preview
    const edgeUrl = this.env.TOKOWAKA_EDGE_URL;
    if (!hasText(edgeUrl)) {
      throw this.#createError(
        'TOKOWAKA_EDGE_URL is required for preview functionality',
        HTTP_INTERNAL_SERVER_ERROR,
      );
    }

    // Validate which suggestions can be deployed using mapper's canDeploy method
    const {
      eligible: eligibleSuggestions,
      ineligible: ineligibleSuggestions,
    } = filterEligibleSuggestions(suggestions, mapper);

    this.log.info(
      `Previewing ${eligibleSuggestions.length} eligible suggestions `
      + `(${ineligibleSuggestions.length} ineligible)`,
    );

    if (eligibleSuggestions.length === 0) {
      this.log.warn('No eligible suggestions to preview');
      return {
        config: null,
        succeededSuggestions: [],
        failedSuggestions: ineligibleSuggestions,
      };
    }

    // Get the preview URL from the first suggestion
    const previewUrl = eligibleSuggestions[0].getData()?.url;
    if (!hasText(previewUrl)) {
      throw this.#createError('Preview URL not found in suggestion data', HTTP_BAD_REQUEST);
    }

    // Fetch metaconfig and existing config in parallel
    const [metaconfig, existingConfig] = await Promise.all([
      this.fetchMetaconfig(previewUrl).catch(() => null),
      this.fetchConfig(previewUrl, false),
    ]);

    let apiKey;
    if (metaconfig && Array.isArray(metaconfig.apiKeys) && metaconfig.apiKeys.length > 0) {
      [apiKey] = metaconfig.apiKeys;
      this.log.info('Using API key from metaconfig');
    } else {
      this.log.info('Proceeding with preview without API key');
    }

    const forwardedHost = calculateForwardedHost(previewUrl, this.log);

    const originalHtmlPromise = fetchHtmlWithWarmup(
      previewUrl,
      apiKey,
      forwardedHost,
      edgeUrl,
      this.log,
      false,
      options,
    ).catch((err) => {
      this.log.error(`Failed to fetch original HTML: ${err.message}`);
      return null;
    });

    // Generate configuration with eligible preview suggestions
    this.log.info(`Generating preview Tokowaka config for opportunity ${opportunity.getId()}`);
    const newConfig = this.generateConfig(previewUrl, opportunity, eligibleSuggestions);

    if (!newConfig) {
      this.log.warn('No config generated for preview');
      return {
        config: null,
        succeededSuggestions: [],
        failedSuggestions: suggestions,
      };
    }

    /* c8 ignore next 9 */
    if (newConfig.patches.length === 0 && !mapper.allowConfigsWithoutPatch()) {
      this.log.warn('No eligible suggestions to preview');
      return {
        config: null,
        succeededSuggestions: [],
        failedSuggestions: suggestions,
      };
    }

    // preview for all: never drop stale suggestions that are being previewed
    newConfig.patches = newConfig.patches.map((patch) => ({
      ...patch,
      applyStale: true,
    }));

    // Merge with existing deployed config to include already-deployed patches for this URL
    let config = newConfig;
    if (existingConfig && existingConfig.patches?.length > 0) {
      this.log.info(
        `Found ${existingConfig.patches.length} deployed patches, merging with preview suggestions`,
      );

      // Merge the existing deployed patches with new preview suggestions
      config = this.mergeConfigs(existingConfig, newConfig);

      this.log.info(
        `Preview config now has ${config.patches.length} total patches`,
      );
    } else {
      this.log.info('No deployed patches found, using only preview suggestions');
    }

    // Upload to preview S3 path for this URL
    // eslint-disable-next-line max-len
    this.log.info(`Uploading preview Tokowaka config with ${eligibleSuggestions.length} new suggestions`);
    const s3Path = await this.uploadConfig(previewUrl, config, true);

    // Fetch HTML content for preview
    let originalHtml = null;
    let optimizedHtml = null;
    let cdnInvalidationResults = null;

    try {
      // Invalidate CDN so edge serves fresh content for optimized fetch
      cdnInvalidationResults = await this.invalidateCdnCache({
        urls: [previewUrl],
        isPreview: true,
      });

      // Await original HTML (started earlier) and fetch optimized HTML in parallel
      const fetchStartTime = Date.now();
      [originalHtml, optimizedHtml] = await Promise.all([
        originalHtmlPromise,
        fetchHtmlWithWarmup(
          previewUrl,
          apiKey,
          forwardedHost,
          edgeUrl,
          this.log,
          true,
          options,
        ),
      ]);
      /* c8 ignore start */
      if (!originalHtml || !optimizedHtml) {
        // eslint-disable-next-line max-len
        throw this.#createError('Failed to fetch original or optimized HTML', HTTP_INTERNAL_SERVER_ERROR);
      }
      /* c8 ignore stop */
      this.log.info('Successfully fetched original and optimized HTML'
        + ` in ${Date.now() - fetchStartTime}ms`);
    } catch (error) {
      this.log.error(`Failed to fetch HTML for preview: ${error.message}`);
      throw this.#createError(
        `Preview failed: Unable to fetch HTML - ${error.message}`,
        HTTP_INTERNAL_SERVER_ERROR,
      );
    }

    return {
      s3Path,
      config,
      cdnInvalidations: cdnInvalidationResults,
      succeededSuggestions: eligibleSuggestions,
      failedSuggestions: ineligibleSuggestions,
      html: {
        url: previewUrl,
        originalHtml,
        optimizedHtml,
      },
    };
  }

  /**
   * Checks if Edge Optimize is enabled for a specific page path
   * Follows one level of redirect and retries on failures
   * @param {Object} site - Site entity
   * @param {string} path - Path to check (e.g., '/products/chair')
   * @returns {Promise<Object>} - Status result with edgeOptimizeEnabled flag
   */
  async checkEdgeOptimizeStatus(site, path) {
    if (!isNonEmptyObject(site)) {
      throw this.#createError('Site is required', HTTP_BAD_REQUEST);
    }

    if (!hasText(path)) {
      throw this.#createError('Path is required', HTTP_BAD_REQUEST);
    }

    const currentConfig = site.getConfig();
    const existingEdgeConfig = currentConfig?.getEdgeOptimizeConfig();
    const isAlreadyEnabled = existingEdgeConfig?.enabled ?? false;
    if (isAlreadyEnabled) {
      return { edgeOptimizeEnabled: true };
    }

    const defaultProbeHeaders = {
      // eslint-disable-next-line max-len
      'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36 Tokowaka-AI Tokowaka/1.0 AdobeEdgeOptimize-AI AdobeEdgeOptimize/1.0',
      'fastly-debug': '1',
    };
    const customHeaders = currentConfig?.getScraperConfig?.()?.headers ?? {};
    const probeHeaders = { ...customHeaders, ...defaultProbeHeaders };

    const baseURL = getEffectiveBaseURL(site);
    const targetUrl = new URL(path, baseURL).toString();

    this.log.info(`[edge-optimize-status] Checking edge optimize status for ${targetUrl}`);

    const maxRetries = 3;
    let attempt = 0;

    const REQUEST_TIMEOUT_MS = 5000;

    while (attempt <= maxRetries) {
      try {
        // eslint-disable-next-line max-len
        this.log.debug(`[edge-optimize-status] Attempt ${attempt + 1}/${maxRetries + 1}: Checking edge optimize status for ${targetUrl}`);

        // eslint-disable-next-line no-await-in-loop
        const response = await tracingFetch(targetUrl, {
          method: 'GET',
          headers: probeHeaders,
          timeout: REQUEST_TIMEOUT_MS,
        });

        this.log.info(`[edge-optimize-status] Response status: ${response.status} for ${targetUrl}`);

        const edgeOptimizeEnabled = response.headers.get('x-tokowaka-request-id') !== null
          || response.headers.get('x-edgeoptimize-request-id') !== null;

        this.log.info(`[edge-optimize-status] Edge optimize headers found: ${edgeOptimizeEnabled} for ${targetUrl}`);

        return {
          edgeOptimizeEnabled,
        };
      } catch (error) {
        const isTimeout = error?.code === 'ETIMEOUT';

        if (isTimeout) {
          // eslint-disable-next-line max-len
          this.log.warn(`[edge-optimize-status] Request timed out after ${REQUEST_TIMEOUT_MS}ms for ${targetUrl}, returning edgeOptimizeEnabled: false`);
          return { edgeOptimizeEnabled: false };
        }

        attempt += 1;

        if (attempt > maxRetries) {
          // All retries exhausted
          this.log.error(`[edge-optimize-status] Failed after ${maxRetries + 1} attempts: ${error.message} for ${targetUrl}`);
          throw this.#createError(
            `Failed to check edge optimize status: ${error.message}`,
            HTTP_INTERNAL_SERVER_ERROR,
          );
        }

        // Exponential backoff: 200ms, 400ms, 800ms
        const delay = 100 * (2 ** attempt);
        this.log.warn(
          `[edge-optimize-status] Attempt ${attempt} to fetch failed: ${error.message}. Retrying in ${delay}ms... for ${targetUrl}`,
        );
        // eslint-disable-next-line no-await-in-loop
        await new Promise((res) => {
          setTimeout(res, delay);
        });
      }
    }
    /* c8 ignore start */
    // This should never be reached, but needed for consistent-return
    throw this.#createError(
      'Failed to check edge optimize status after all retries',
      HTTP_INTERNAL_SERVER_ERROR,
    );
    /* c8 ignore stop */
  }

  /**
   * Probes whether a WAF or Bot Manager is blocking AdobeEdgeOptimize/1.0 traffic
   * for the site.
   *
   * Probe outcomes:
   * - Hard block: HTTP 401/403/406/429/503 → `{ reachable: false, blocked: true }`
   * - CF challenge: cf-mitigated: challenge header → `{ reachable: false, blocked: true }`
   * - Soft block: 2xx with bot-challenge HTML → `{ reachable: false, blocked: true }`
   * - Pass: 2xx with real content → `{ reachable: true, blocked: false }`
   * - Network/timeout error → `{ reachable: false, blocked: null }`
   *
   * This method never throws — all errors are captured into the return value.
   * Use the separate edge-optimize status API to determine if edge optimize is active.
   *
   * @param {Object} site - Site entity with a `getBaseURL()` method.
   * @returns {Promise<Object>} WAF probe result.
   */
  async checkWafConnectivity(site) {
    const siteBaseUrl = site.getBaseURL();
    let probeResult = { probedUrl: String(siteBaseUrl) };

    try {
      const normalizedUrl = prependSchema(siteBaseUrl);
      const { host: targetHost, hostname, href: probedUrl } = new URL(normalizedUrl);
      probeResult = { probedUrl };

      if (PRIVATE_HOST_RE.test(hostname)) {
        this.log.warn(`[edge-optimize-probe] Refusing to probe private/loopback host: ${hostname}`);
        return { ...probeResult, reachable: false, blocked: null };
      }

      this.log.info(`[edge-optimize-probe] Probing ${targetHost} via edge optimize proxy`);

      const response = await tracingFetch(EDGE_OPTIMIZE_PROXY_BASE_URL_DEFAULT, {
        method: 'GET',
        headers: { 'x-forwarded-host': targetHost },
        signal: AbortSignal.timeout(WAF_PROBE_TIMEOUT_MS),
      });

      const classification = await classifyProbeResponse(response, targetHost, this.log);
      probeResult = { ...probeResult, ...classification };
    } catch (error) {
      this.log.warn(`[edge-optimize-probe] Probe failed for ${siteBaseUrl}: ${error.message}`);
      probeResult = { ...probeResult, reachable: false, blocked: null };
    }

    return probeResult;
  }

  /**
   * Deploys per-URL suggestions via deploySuggestions(), stamps them with edgeDeployed,
   * and returns { succeededSuggestions, failedSuggestions }.
   * Throws if the underlying deployment throws.
   * @param {Object} site
   * @param {Object} opportunity
   * @param {Array} validSuggestions
   * @param {string} updatedBy
   * @returns {Promise<{ succeededSuggestions: Array, failedSuggestions: Array }>}
   * @private
   */
  // eslint-disable-next-line max-len
  async #deployPerUrlSuggestions(site, opportunity, validSuggestions, updatedBy, metadata = {}) {
    try {
      // eslint-disable-next-line max-len
      const result = await this.deploySuggestions(site, opportunity, validSuggestions, metadata);
      const deploymentTimestamp = Date.now();

      const succeeded = result.succeededSuggestions.map((s) => {
        const currentData = s.getData();
        const updated = { ...currentData, edgeDeployed: deploymentTimestamp };
        const statusesToExcludeFromOptimization = ['STALE', 'LAST_MOD_MISSING'];
        if (statusesToExcludeFromOptimization.includes(updated.edgeOptimizeStatus)) {
          delete updated.edgeOptimizeStatus;
        }
        s.setData(updated);
        s.setUpdatedBy(updatedBy);
        return s;
      });
      await saveSuggestions(this.dataAccess, succeeded);

      const failed = result.failedSuggestions.map((item) => {
        this.log.info(
          `[edge-deploy] ${opportunity.getType()} suggestion `
          + `${item.suggestion.getId()} is ineligible: ${item.reason}`,
        );
        return { ...item, statusCode: 400 };
      });

      return { succeededSuggestions: succeeded, failedSuggestions: failed };
    } catch (error) {
      this.log.error(`[edge-deploy] Error deploying suggestions: ${error.message}`, error);
      throw error;
    }
  }

  /**
   * Deploys a single pattern suggestion by appending its patterns to the metaconfig allowList
   * (append-and-deduplicate; CDN write is skipped when nothing changes), stamps the suggestion
   * with edgeDeployed, and marks qualifying per-URL suggestions as covered.
   * @param {Object} suggestion - The pattern suggestion entity
   * @param {Array<string>} allowedRegexPatterns
   * @param {Object} metaconfig - Metaconfig object (mutated in place)
   * @param {string} baseURL
   * @param {Set<string>} skippedInBatchIds - IDs already handled as same-batch skips
   * @param {Array} allSuggestions - Full opportunity suggestion list
   * @param {string} updatedBy
   * @param {Array} coveredSuggestions - Accumulator (mutated)
   * @param {string} siteId
   * @returns {Promise<void>} Throws on metaconfig upload failure
   * @private
   */
  async #deployPatternSuggestion(
    suggestion,
    allowedRegexPatterns,
    metaconfig,
    baseURL,
    skippedInBatchIds,
    allSuggestions,
    updatedBy,
    coveredSuggestions,
    siteId,
  ) {
    const data = suggestion.getData();
    const coverageField = data?.isDomainWide ? 'coveredByDomainWide' : 'coveredByPattern';

    const beforeAllowList = metaconfig.prerender?.allowList ?? [];
    const changed = addPatternsToMetaconfig(metaconfig, allowedRegexPatterns);
    const afterAllowList = changed ? metaconfig.prerender.allowList : beforeAllowList;
    this.log.info(
      // eslint-disable-next-line max-len
      `[edge-deploy] Pattern ${suggestion.getId()}: allowList before=${JSON.stringify(beforeAllowList)}, after=${JSON.stringify(afterAllowList)}`,
    );

    if (changed) {
      await this.uploadMetaconfig(baseURL, metaconfig);
      // eslint-disable-next-line max-len
      this.log.info(`[edge-deploy] Uploaded metaconfig for ${baseURL} with allowList=${JSON.stringify(afterAllowList)}`);
    } else {
      // eslint-disable-next-line max-len
      this.log.info(`[edge-deploy] Patterns already in allowList for suggestion ${suggestion.getId()}, skipping CDN write`);
    }

    suggestion.setData({ ...suggestion.getData(), edgeDeployed: Date.now() });
    suggestion.setUpdatedBy(updatedBy);
    // suggestion.save() is deferred — caller batches saves via saveSuggestions.

    const covered = findCoveredSuggestions(
      suggestion,
      allowedRegexPatterns,
      allSuggestions,
      skippedInBatchIds,
      this.log,
    );

    // eslint-disable-next-line max-len
    this.log.info(`[edge-deploy] Pattern ${suggestion.getId()}: found ${covered.length} coverable per-URL suggestions (field=${coverageField})`);

    if (covered.length > 0) {
      covered.forEach((cs) => {
        cs.setData({ ...cs.getData(), [coverageField]: suggestion.getId() });
        cs.setUpdatedBy(updatedBy);
      });
      try {
        await saveSuggestions(this.dataAccess, covered, {
          sqs: this.sqs,
          queueUrl: this.importWorkerQueueUrl,
          siteId,
          set: { [coverageField]: suggestion.getId() },
          updatedBy,
          log: this.log,
        });
        coveredSuggestions.push(...covered);
        // eslint-disable-next-line max-len
        this.log.info(`[edge-deploy] Marked ${covered.length} suggestions as ${coverageField}=${suggestion.getId()}`);
      } catch (coverError) {
        this.log.warn(
          '[edge-deploy] Failed to mark covered suggestions for pattern suggestion '
          + `${suggestion.getId()}: ${coverError.message}`,
        );
      }
    }
  }

  /**
   * Deploys suggestions to edge, handling both regular and domain-wide suggestions.
   *
   * Regular suggestions are deployed via deploySuggestions(). Domain-wide suggestions
   * update the site metaconfig's prerender allowList. Suggestions covered by domain-wide
   * patterns (in the same batch or across the whole opportunity) are automatically marked.
   *
   * @param {Object} params
   * @param {Object} params.site - Site entity
   * @param {Object} params.opportunity - Opportunity entity
   * @param {Array}  params.targetSuggestions - Suggestions selected for this deployment
   * @param {Array}  params.allSuggestions - All suggestions for the opportunity
   * @param {string} [params.updatedBy='edge-deploy'] - Value for updatedBy on saved suggestions
   * @returns {Promise<Object>} { succeededSuggestions, failedSuggestions, coveredSuggestions }
   *   - succeededSuggestions: suggestion entities that were deployed
   *   - failedSuggestions: { suggestion, reason } items that couldn't be deployed
   *   - coveredSuggestions: suggestion entities auto-marked via domain-wide patterns
   */
  async deployToEdge({
    site,
    opportunity,
    targetSuggestions,
    allSuggestions,
    updatedBy = 'edge-deploy',
    metadata = {},
  }) {
    // Step 1: classify suggestions into pattern vs per-URL buckets.
    // eslint-disable-next-line max-len
    const { patternSuggestions, validSuggestions: classified } = classifySuggestions(targetSuggestions, this.log);
    this.log.info(
      `[edge-deploy] Classification: pattern=${patternSuggestions.length},`
      + ` perUrl=${classified.length}, allSuggestions=${allSuggestions.length}`,
    );

    // Step 2: remove per-URL suggestions already covered by a pattern in this batch.
    // eslint-disable-next-line max-len
    const { remaining: validSuggestions, skippedInBatch } = filterBatchCoveredSuggestions(classified, patternSuggestions, this.log);

    let succeededSuggestions = [];
    const failedSuggestions = [];

    // Step 3: deploy per-URL suggestions via S3.
    if (validSuggestions.length > 0) {
      // eslint-disable-next-line max-len
      const result = await this.#deployPerUrlSuggestions(site, opportunity, validSuggestions, updatedBy, metadata);
      const { succeededSuggestions: perUrlSucceeded, failedSuggestions: perUrlFailed } = result;
      succeededSuggestions = perUrlSucceeded;
      failedSuggestions.push(...perUrlFailed);
    }

    // Step 4: deploy pattern suggestions via metaconfig allowList.
    const coveredSuggestions = [];
    const deployedPatternSuggestions = [];
    if (patternSuggestions.length > 0) {
      const skippedInBatchIds = new Set(skippedInBatch.map((item) => item.suggestion.getId()));
      const baseURL = site.getBaseURL();
      let metaconfig = await this.fetchMetaconfig(baseURL);
      if (!metaconfig) {
        metaconfig = { siteId: site.getId() };
      }

      for (const { suggestion, allowedRegexPatterns } of patternSuggestions) {
        if (!allowedRegexPatterns || allowedRegexPatterns.length === 0) {
          // eslint-disable-next-line max-len
          this.log.warn(`[edge-deploy] Pattern suggestion ${suggestion.getId()} has no allowedRegexPatterns, skipping`);
          // eslint-disable-next-line no-continue
          continue;
        }

        try {
          // eslint-disable-next-line no-await-in-loop
          await this.#deployPatternSuggestion(
            suggestion,
            allowedRegexPatterns,
            metaconfig,
            baseURL,
            skippedInBatchIds,
            allSuggestions,
            updatedBy,
            coveredSuggestions,
            site.getId(),
          );
          deployedPatternSuggestions.push(suggestion);
        } catch (error) {
          // eslint-disable-next-line max-len
          this.log.error(`[edge-deploy] Error deploying pattern suggestion ${suggestion.getId()}: ${error.message}`, error);
          failedSuggestions.push({ suggestion, reason: 'Internal server error', statusCode: 500 });
        }
      }

      // Batch-save all pattern suggestions.
      if (deployedPatternSuggestions.length > 0) {
        try {
          await saveSuggestions(this.dataAccess, deployedPatternSuggestions);
          succeededSuggestions.push(...deployedPatternSuggestions);
        } catch (error) {
          // eslint-disable-next-line max-len
          this.log.error(`[edge-deploy] Failed to save pattern suggestions: ${error.message}`);
          deployedPatternSuggestions.forEach((s) => {
            failedSuggestions.push({ suggestion: s, reason: 'Internal server error', statusCode: 500 });
          });
        }
      }
    }

    // Step 5: mark same-batch skipped suggestions, then batch-save.
    if (skippedInBatch.length > 0) {
      const skippedSuggestions = skippedInBatch.map((item) => {
        const coverageField = item.isDomainWide ? 'coveredByDomainWide' : 'coveredByPattern';
        item.suggestion.setData({
          ...item.suggestion.getData(),
          [coverageField]: 'same-batch-deployment',
          skippedInDeployment: true,
        });
        item.suggestion.setUpdatedBy(updatedBy);
        return item.suggestion;
      });

      try {
        await saveSuggestions(this.dataAccess, skippedSuggestions);
        succeededSuggestions.push(...skippedSuggestions);
        coveredSuggestions.push(...skippedSuggestions);
      } catch (error) {
        // eslint-disable-next-line max-len
        this.log.warn(`[edge-deploy] Failed to save same-batch skipped suggestions: ${error.message}`);
        skippedSuggestions.forEach((s) => {
          // eslint-disable-next-line max-len
          failedSuggestions.push({ suggestion: s, reason: 'Failed to mark as covered', statusCode: 500 });
        });
      }
    }

    return { succeededSuggestions, failedSuggestions, coveredSuggestions };
  }

  /**
   * Finds and marks the suggestions that fall within a pattern suggestion's
   * scope (domain-wide or segment/path) as covered and saves them.
   *
   * @param {Object} patternSuggestion - The domain-wide / segment pattern suggestion
   * @param {Array} allSuggestions - Full opportunity suggestion list to search for matches
   * @param {string} siteId - Site ID
   * @param {string} [updatedBy]
   * @returns {Promise<Array>} the marked suggestions
   */
  async markPatternCoveredSuggestions(
    patternSuggestion,
    allSuggestions,
    siteId,
    updatedBy = 'edge-deploy',
  ) {
    const allowedRegexPatterns = patternSuggestion.getData()?.allowedRegexPatterns;
    if (!Array.isArray(allowedRegexPatterns) || allowedRegexPatterns.length === 0) {
      this.log.warn(`[edge-deploy] Pattern suggestion ${patternSuggestion.getId()} has `
      + 'no allowedRegexPatterns, skipping cover-marking');
      return [];
    }
    const covered = findCoveredSuggestions(
      patternSuggestion,
      allowedRegexPatterns,
      allSuggestions,
      new Set(),
      this.log,
    );
    if (covered.length === 0) {
      return [];
    }
    const coverageField = patternSuggestion.getData()?.isDomainWide
      ? 'coveredByDomainWide' : 'coveredByPattern';
    covered.forEach((s) => {
      s.setData({ ...s.getData(), [coverageField]: patternSuggestion.getId() });
      s.setUpdatedBy(updatedBy);
    });
    try {
      await saveSuggestions(this.dataAccess, covered, {
        sqs: this.sqs,
        queueUrl: this.importWorkerQueueUrl,
        siteId,
        set: { [coverageField]: patternSuggestion.getId() },
        updatedBy,
        log: this.log,
      });
      this.log.info(`[edge-deploy] Marked ${covered.length} suggestions as ${coverageField}=${patternSuggestion.getId()}`);
      return covered;
    } catch (saveError) {
      this.log.warn(
        '[edge-deploy] Failed to mark covered suggestions for pattern suggestion '
        + `${patternSuggestion.getId()}: ${saveError.message}`,
      );
      return [];
    }
  }

  /**
   * Strips the `applyStale` flag from patches in S3 for the given per-URL suggestions.
   * Called when an experiment completes so edge reverts to normal (non-stale) behaviour.
   * Pattern / domain-wide suggestions are skipped — they have no per-URL S3 config.
   * CDN cache is invalidated for every URL whose config was actually modified.
   *
   * @param {Object} site - Site entity
   * @param {Object} opportunity - Opportunity entity
   * @param {Array}  suggestions - Suggestion entities to clear (may include pattern suggestions,
   *   which are silently skipped)
   * @returns {Promise<void>}
   */
  async clearApplyStaleFromPatches(site, opportunity, suggestions) {
    const baseURL = getEffectiveBaseURL(site);

    const perUrlSuggestions = suggestions.filter((s) => {
      const data = s.getData();
      return data?.url && !Array.isArray(data?.allowedRegexPatterns);
    });

    if (perUrlSuggestions.length === 0) {
      return;
    }

    const suggestionsByUrl = groupSuggestionsByUrlPath(perUrlSuggestions, baseURL, this.log);
    const clearedUrls = [];

    for (const [urlPath, urlSuggestions] of Object.entries(suggestionsByUrl)) {
      const fullUrl = new URL(urlPath, baseURL).toString();
      try {
        // eslint-disable-next-line no-await-in-loop
        const existingConfig = await this.fetchConfig(fullUrl);
        if (!existingConfig?.patches?.length) {
          // eslint-disable-next-line no-continue
          continue;
        }

        const suggestionIds = new Set(urlSuggestions.map((s) => s.getId()));
        let modified = false;
        const updatedPatches = existingConfig.patches.map((patch) => {
          if (suggestionIds.has(patch.suggestionId) && patch.applyStale) {
            modified = true;
            const { applyStale: _, ...rest } = patch;
            return rest;
          }
          return patch;
        });

        if (modified) {
          // eslint-disable-next-line no-await-in-loop
          await this.uploadConfig(fullUrl, { ...existingConfig, patches: updatedPatches });
          clearedUrls.push(fullUrl);
        }
      } catch (err) {
        this.log.error(`[clear-apply-stale-failed] Failed to process URL ${fullUrl}: ${err.message}`, err);
      }
    }

    if (clearedUrls.length > 0) {
      try {
        await this.invalidateCdnCache({ urls: clearedUrls });
        this.log.info(`[clear-apply-stale] Cleared applyStale from ${clearedUrls.length} URL(s) and invalidated CDN`);
      } catch (err) {
        this.log.warn(`[clear-apply-stale-failed] CDN invalidation failed for ${clearedUrls.length} URL(s), S3 configs already updated: ${err.message}`, err);
      }
    }
  }
}

// Export the client as default and base classes for custom implementations
export default TokowakaClient;
